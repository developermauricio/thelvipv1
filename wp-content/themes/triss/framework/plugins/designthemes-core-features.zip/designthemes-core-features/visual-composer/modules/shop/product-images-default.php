<?php 

vc_map( array(
	"name" => esc_html__( 'Product Single - Images Default', 'designthemes-core' ),
	"base" => "dt_sc_product_images_default",
	"icon" => "dt_sc_product_images_default",
	"category" => DT_VC_SHOP,
	"params" => array ()
) );

?>